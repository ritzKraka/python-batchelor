
from batchelor import main


def test_main():
    pass
