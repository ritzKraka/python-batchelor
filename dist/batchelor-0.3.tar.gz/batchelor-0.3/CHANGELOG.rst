
Changelog
=========

0.1 (2020-06-12)
----------------

* First release on PyPI.
