
Changelog
=========

0.1 (2020-06-12)
----------------

* First release on PyPI.


0.3 (I forget)
--------------

* Stop doing changelog because I'm too lazy. :)

0.5.5 (last one)
----------------

* Added command-line argument support.
